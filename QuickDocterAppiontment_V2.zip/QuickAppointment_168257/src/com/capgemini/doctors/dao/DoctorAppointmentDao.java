package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.capgemini.doctors.util.DBConnecton;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.bean.ProblemsBean;
import com.capgemini.doctors.exception.DoctorsException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorsException {
		Connection conn;

		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, doctorAppointment.getPatientName());
			insertStmt.setString(2, doctorAppointment.getPhoneNumber());
			insertStmt.setString(3, doctorAppointment.getEmail());
			insertStmt.setInt(4, doctorAppointment.getAge());
			insertStmt.setString(5, doctorAppointment.getGender());
			insertStmt.setString(6, doctorAppointment.getProblemName());
			insertStmt.setString(7, doctorAppointment.getDoctorName());
			insertStmt.setString(8, doctorAppointment.getAppointmentStatus());

			/*
			 * System.out.println(pd.getCustomerName()); System.out.println(pd.getMailId());
			 * System.out.println(pd.getPhoneNumber());
			 * System.out.println(pd.getPurchasedate());
			 * System.out.println(pd.getMobileId());
			 */

			int result = insertStmt.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new DoctorsException("Sorry! insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {

			throw new DoctorsException(e.getMessage());
		}

		return 1;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorsException {
		Connection con = DBConnecton.getConnection();
		int appdetail = 0;

		PreparedStatement psMobSerStmt = null;
		ResultSet resultset = null;
		DoctorAppointment da = new DoctorAppointment();
		try {
			psMobSerStmt = con.prepareStatement(IQueryMapper.GET_APPOINTMENT_DETAILS);
			psMobSerStmt.setInt(1, appointmentId);
			resultset = psMobSerStmt.executeQuery();
			
			while (resultset.next()) {
				
				
				da.setPatientName(resultset.getString(1));
				da.setAppointmentStatus(resultset.getString(2));
				da.setDoctorName(resultset.getString(3));
				da.setDateOfAppointment(resultset.getDate(4));
				

				

				appdetail++;
			}
			
		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new DoctorsException("Tehnical problem occured. Refer log");
		}

		if (appdetail == 0) {
			return null;
		} else {
			return da;
		}
	}

	@Override
	public List<String> getProblemNames() throws DoctorsException {

		Connection con = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		List<String> mobileIDsList = new ArrayList<String>();
		try {
			psMobIDStmt = con.prepareStatement(IQueryMapper.GET_PROBLEM_NAMES);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList.add(resultsetMobId.getString(1));

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			
			throw new DoctorsException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new DoctorsException("Error in closing db connection");

			}
		}

		if (mobileIDsCount == 0)
			return null;
		else
			return mobileIDsList;
	}

	@Override
	public String getDoctorName(String probName) throws DoctorsException {
		Connection con = DBConnecton.getConnection();
		int docCount = 0;

		PreparedStatement psMobSerStmt = null;
		ResultSet resultset = null;
		String Doctor = null;

		//List<String> docList = new ArrayList<String>();
		try {
			psMobSerStmt = con.prepareStatement(IQueryMapper.SEARCH_DOCTOR);
			psMobSerStmt.setString(1, probName);
			resultset = psMobSerStmt.executeQuery();
			

			while (resultset.next()) {
				//prb.setDoctorName(resultset.getString(1));
				//docList.add(resultset.getString(1));
				 Doctor = resultset.getString(1);
				

				docCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new DoctorsException("Doctor name method Tehnical problem occured. Refer log");
		}

		if (docCount == 0) {
			return null;
		} else {
			return Doctor;
		}
	}

	@Override
	public int getAppointmentId() throws DoctorsException {
		Connection conn;
		PreparedStatement getAppmStmt = null;
		ResultSet appointIdResult = null;
		int appointid = 0;
		try {
			conn = DBConnecton.getConnection();
			getAppmStmt = conn.prepareStatement(IQueryMapper.GET_APPOINTMENT_ID);
			appointIdResult = getAppmStmt.executeQuery();
			if (appointIdResult.next()) {
				appointid = appointIdResult.getInt(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (DoctorsException e) {
			throw new DoctorsException("Sorry purchseid not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DoctorsException("Sorry purchseid sql exception genrated");

		}

		return appointid;
	}

}
