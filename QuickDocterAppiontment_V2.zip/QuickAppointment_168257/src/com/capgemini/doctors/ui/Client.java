package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {
	private static Scanner in;

	private static IDoctorAppointmentService ida = new DoctorAppointmentService();
	
	






	public static void main(String[] args) throws DoctorsException {

		in = new Scanner(System.in);
		System.out.println(" \nWelcome to mobile purchase portal\n");
		while (true) {
			System.out.println(" \nEnter your choice:\n");
			System.out.println(" 1.Book Doctor Appointement\n");
			System.out.println(" 2.View Doctor Appointement\n");
			System.out.println(" 3.Exit\n");
			int choice = in.nextInt();
			switch (choice) {

			case 1:
				getInputs();
				break;

			case 2:
				System.out.println("Enter your Appointment ID");
				int ID = in.nextInt();
				//ida.getAppointmentDetails(ID);
				viewAppointment(ID);
				break;

			case 3:
				System.out.println("\n\nThank you");
				System.exit(0);

			}

		}

	}
	
	
	
private static void getInputs() throws DoctorsException {
		
		String patientName;
		String PhoneNumber;
		String email;
		int age;
		String gender;
		String problemName;
		String status;
		
		DoctorAppointment da = new DoctorAppointment();

		

			while (true) {
				in.nextLine();
				System.out.println("Enter patient name");

				patientName = in.nextLine();

				if (ida.validatePatientName(patientName)) {
					break;
				} else {
					System.out.println("Invalid patient name");
				}
			}

			while (true) {
				System.out.println("Enter phone number");

				PhoneNumber = in.next();

				if (ida.validatePhoneNumber(PhoneNumber)) {
					break;
				} else {
					System.out.println("Invalid phone number");
				}
			}

			while (true) {
				System.out.println("Please enter mail id ");

				email = in.next();

				if (ida.validateMailId(email)) {
					break;
				} else {
					System.out.println("Invalid mail id");
				}
			}

			while (true) {
				System.out.println("Please enter age ");

				age = in.nextInt();
				String Age = Integer.toString(age);

				if (ida.validateAge(Age)) {
					break;
				} else {
					System.out.println("Invalid age");
				}
			}

			while (true) {
				System.out.println("Please enter gender");

				gender = in.next();

				if (ida.validateGender(gender)) {
					break;
				} else {
					System.out.println("Invalid gender");
				}
			}
			
				System.out.println("Enter Problem name");
				problemName = in.next();
				problemName = problemName.toLowerCase();
				if (ida.getProblemNames().contains(problemName)) {
					status = "Approved";
				} else {
					status = "DisApproved";
					
				}
			
				
				da.setPatientName(patientName);
				da.setPhoneNumber(PhoneNumber);
				da.setEmail(email);
				da.setAge(age);
				da.setGender(gender);
				da.setProblemName(problemName);
				da.setAppointmentStatus(status);
				da.setDoctorName(ida.getDoctorName(problemName));
				
				ida.addDoctorAppointmentDetails(da);
				System.out.println("your Appointment ID: "+ida.getAppointmentId());
			
	}




private static void viewAppointment(int appointmentId) {
	try {
		
		DoctorAppointment da = ida.getAppointmentDetails(appointmentId);

		
				System.out.println("Patient Name: "+da.getPatientName());
				System.out.println("Appointmen Statust: "+ da.getAppointmentStatus());
				System.out.println("Doctor Name: "+ da.getDoctorName());
				System.out.println("Date Of Appointment: "+ da.getDateOfAppointment());

	} catch (DoctorsException e) {

		System.out.println("Error  :" + e.getMessage());
	}

}




}
