package com.capgemini.doctors.service;

import java.util.List;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;

public interface IDoctorAppointmentService {
	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorsException;
	
	DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorsException;
	
	public List<String> getProblemNames() throws DoctorsException;
	
	boolean validatePatientName(String ptientname);

	boolean validatePhoneNumber(String PhoneNumber);

	boolean validateAge(String age);

	boolean validateMailId(String MailId);
	
	boolean validateGender(String gender);
	
	public int getAppointmentId() throws DoctorsException;
	
	public String getDoctorName(String probName) throws DoctorsException;

}
