package com.capgemini.doctors.exception;

public class DoctorsException extends Exception {
	public DoctorsException(String msg) {
		super(msg);
	}

}
